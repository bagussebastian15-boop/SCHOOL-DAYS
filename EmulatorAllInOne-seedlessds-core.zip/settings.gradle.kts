pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // Google Maven hanya ditanya untuk grup milik Google/AndroidX. Dulu SEMUA dependensi (mis. junrar) ditanyakan
        // ke dl.google.com dulu, sehingga "Read timed out" di sana menggagalkan build walau junrar ada di Maven Central.
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        maven("https://jitpack.io") {
            content { includeGroup("com.github.Swordfish90") }
        }
    }
}
rootProject.name = "EmulatorAllInOne"
include(":app")
// LibretroDroid dibangun dari sumber (dengan patch netplay rollback). Siapkan dengan: bash scripts/setup_libretrodroid_netplay.sh
include(":libretrodroid")
project(":libretrodroid").projectDir = file("libretrodroid-src/libretrodroid")

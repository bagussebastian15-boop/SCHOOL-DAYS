#!/usr/bin/env bash
# Uji mesin ZeroTier tertanam (ZtEngine) terhadap SDK palsu, tanpa Android dan tanpa jaringan sungguhan.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
if command -v javac >/dev/null 2>&1; then JAVAC=(javac); else JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
"${JAVAC[@]}" -encoding UTF-8 -d "$OUT" \
  app/src/main/java/com/allinone/emulator/net/EthBridge.java \
  app/src/main/java/com/allinone/emulator/net/ZtEngine.java \
  tests/java/com/zerotier/sdk/*.java \
  tests/java/com/allinone/emulator/net/ZtEngineTest.java
java -Dfile.encoding=UTF-8 -cp "$OUT" com.allinone.emulator.net.ZtEngineTest

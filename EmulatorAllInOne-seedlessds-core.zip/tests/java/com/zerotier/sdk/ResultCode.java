package com.zerotier.sdk;
public enum ResultCode { RESULT_OK, RESULT_FATAL_ERROR_INTERNAL }

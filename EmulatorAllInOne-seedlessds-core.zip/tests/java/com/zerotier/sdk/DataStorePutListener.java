package com.zerotier.sdk;
public interface DataStorePutListener { int onDataStorePut(String name, byte[] buffer, boolean secure); int onDelete(String name); }

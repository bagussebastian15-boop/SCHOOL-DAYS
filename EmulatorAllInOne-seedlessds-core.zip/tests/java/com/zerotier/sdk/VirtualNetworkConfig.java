package com.zerotier.sdk;
import java.net.InetSocketAddress;
import java.util.ArrayList;
public class VirtualNetworkConfig {
    public long mac; public String name; public VirtualNetworkStatus status; public int mtu; public InetSocketAddress[] addrs = new InetSocketAddress[0];
    public long getMac() { return mac; }
    public String getName() { return name; }
    public VirtualNetworkStatus getStatus() { return status; }
    public int getMtu() { return mtu; }
    public InetSocketAddress[] getAssignedAddresses() { return addrs; }
}

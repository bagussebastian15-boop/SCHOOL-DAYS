package com.zerotier.sdk;
public interface DataStoreGetListener { long onDataStoreGet(String name, byte[] buffer, long bufferIndex, long[] out_objectSize); }

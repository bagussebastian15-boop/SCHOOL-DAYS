package com.zerotier.sdk;
public interface VirtualNetworkFrameListener { void onVirtualNetworkFrame(long networkId, long srcMac, long destMac, long etherType, long vlanId, byte[] frameData); }

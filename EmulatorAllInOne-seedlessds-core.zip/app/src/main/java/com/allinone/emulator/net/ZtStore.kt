package com.allinone.emulator.net

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Daftar jaringan ZeroTier yang ditambahkan pemain + pengaturan VPN tertanam. */
object ZtStore {
    data class Net(val id: String, var name: String, var on: Boolean)

    private fun p(c: Context) = c.getSharedPreferences("zerotier", Context.MODE_PRIVATE)

    fun isNetworkId(s: String) = Regex("^[0-9a-f]{16}$").matches(s)

    /** Jaringan bawaan aplikasi: selalu ada di daftar, pemain cukup menyalakan toggle lalu menunggu di-Auth. */
    val DEFAULTS: List<Pair<String, String>> = listOf(
        "8d1c312afa20d47e" to "Bit\u00A9ade",
        "166359304e77bd40" to "Bit\u00A9ade 2",
        "3b19b3a71692f900" to "Bit\u00A9ade 3",
        "76fc96e4989e0f75" to "Bit\u00A9ade 4",
        "3b19b3a7169a6bda" to "Bit\u00A9ade 5"
    )

    fun isDefault(id: String) = DEFAULTS.any { it.first == id }

    fun list(c: Context): MutableList<Net> {
        val stored = ArrayList<Net>()
        try {
            val a = JSONArray(p(c).getString("networks", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.optString("id")
                if (isNetworkId(id)) stored += Net(id, o.optString("name", id), o.optBoolean("on", true))
            }
        } catch (_: Exception) { }
        // Bawaan dulu (urutan tetap, nama tetap, status nyala/mati ikut pilihan pemain; baru = mati), lalu jaringan tambahan pemain.
        val out = ArrayList<Net>()
        var changed = false
        for ((id, name) in DEFAULTS) {
            val cur = stored.firstOrNull { it.id == id }
            if (cur == null) { out += Net(id, name, false); changed = true }
            else { if (cur.name != name) changed = true; out += Net(id, name, cur.on) }
        }
        stored.filter { !isDefault(it.id) }.forEach { out += it }
        if (changed || out.size != stored.size) save(c, out)
        return out
    }

    fun save(c: Context, l: List<Net>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("on", it.on)) }
        p(c).edit().putString("networks", a.toString()).apply()
    }

    /** Menambah jaringan (atau menghidupkan lagi bila sudah ada). false bila Network ID tidak valid. */
    fun add(c: Context, id: String, name: String): Boolean {
        val nid = id.trim().lowercase()
        if (!isNetworkId(nid)) return false
        val l = list(c)
        val cur = l.firstOrNull { it.id == nid }
        if (cur != null) { cur.on = true; if (name.isNotBlank()) cur.name = name } else l += Net(nid, name.ifBlank { nid }, true)
        save(c, l)
        return true
    }

    fun setOn(c: Context, id: String, on: Boolean) {
        val l = list(c); l.firstOrNull { it.id == id }?.on = on; save(c, l)
    }

    /** Jaringan bawaan tidak bisa dihapus. */
    fun remove(c: Context, id: String) { if (!isDefault(id)) save(c, list(c).filter { it.id != id }) }

    /** Izinkan ZeroTier berjalan lewat data seluler (bawaan: mati, seperti ZeroTier One). */
    fun allowCellular(c: Context): Boolean = p(c).getBoolean("cellular", false)

    fun setAllowCellular(c: Context, v: Boolean) = p(c).edit().putBoolean("cellular", v).apply()

    fun dataDir(c: Context) = File(c.filesDir, "zerotier")

    /** Node ID milik aplikasi ini (kosong bila ZeroTier tertanam belum pernah dijalankan). */
    fun nodeId(c: Context): String = ZtState.nodeId.ifBlank { ZtEngine.peekNodeId(dataDir(c)) }
}

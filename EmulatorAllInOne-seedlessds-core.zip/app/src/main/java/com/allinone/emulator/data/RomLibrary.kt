package com.allinone.emulator.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipOutputStream
import com.github.junrar.Archive
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.util.zip.ZipEntry
import android.util.Log
import java.util.zip.ZipFile

data class Game(val file: File, val console: Console) {
    val title: String get() = file.nameWithoutExtension
}

object RomLibrary {

    /** Folder core arcade lama (FBNeo dan FB Alpha 2012 sudah dihapus): ROM-nya dipindah ke folder MAME 2010. */
    private fun migrateOldArcade(ctx: Context) {
        val dest = Paths.roms(ctx, Console.ARCADE_MAME)
        for (old in listOf("arcade_fbneo", "arcade_fba2012")) {
            val dir = File(Paths.roms(ctx, Console.ARCADE_MAME).parentFile, old)
            dir.listFiles().orEmpty().filter { it.isFile }.forEach { f ->
                val t = File(dest, f.name)
                if (!t.exists()) f.renameTo(t) else f.delete()
            }
            dir.delete()
        }
    }

    private val checkedZips = HashSet<String>()

    /** Konsol pemilik sebuah file ROM, dari nama folder induknya. */
    fun consoleOf(f: File): Console? = Console.values().firstOrNull { it.name.lowercase() == f.parentFile?.name }

    private val ARCHIVE_EXT = setOf("zip", "7z", "rar")
    fun isArchive(name: String) = name.substringAfterLast('.', "").lowercase() in ARCHIVE_EXT

    /** Berkas pelengkap yang sering ikut di zip ROM (tidak mengubah keputusan konsol). */
    private val JUNK_EXT = setOf("txt", "nfo", "jpg", "jpeg", "png", "gif", "url", "diz", "md", "pdf", "htm", "html", "ini", "doc", "docx", "xml", "db", "ds_store")

    private fun extOf(n: String) = n.substringAfterLast('.', "").lowercase()
    private fun flat(n: String) = n.replace('\\', '/').substringAfterLast('/')

    /** Daftar nama file (bukan folder) di dalam arsip .zip / .7z / .rar; null bila tidak terbaca. */
    private fun entryNames(f: File): List<String>? = try {
        when (extOf(f.name)) {
            "zip" -> ZipFile(f).use { z -> z.entries().asSequence().filter { !it.isDirectory }.map { it.name }.toList() }
            "7z" -> SevenZFile(RandomAccessFile(f, "r").channel).use { z ->
                z.entries.filter { !it.isDirectory }.map { it.name }
            }
            "rar" -> Archive(f).use { a -> a.fileHeaders.filter { !it.isDirectory }.map { it.fileName } }
            else -> null
        }
    } catch (e: Throwable) {
        val msg = "Arsip ${f.name} tidak terbaca: ${e.javaClass.simpleName} ${e.message ?: ""}".trim()
        lastError = msg
        Log.w("RomLibrary", msg, e); null
    }

    /** Pesan galat terakhir saat membaca/mengekstrak arsip (untuk laporan). */
    @Volatile var lastError: String? = null

    /** Mengekstrak entri bernama (kunci) ke file tujuan (nilai). */
    private fun extractEntries(f: File, targets: Map<String, File>) {
        when (extOf(f.name)) {
            "zip" -> ZipFile(f).use { z ->
                for ((n, t) in targets) {
                    val e = z.getEntry(n) ?: continue
                    z.getInputStream(e).use { i -> t.outputStream().use { o -> i.copyTo(o) } }
                }
            }
            "7z" -> SevenZFile(RandomAccessFile(f, "r").channel).use { z ->
                var e = z.nextEntry
                val buf = ByteArray(64 * 1024)
                while (e != null) {
                    val t = targets[e.name]
                    if (t != null && !e.isDirectory) {
                        t.outputStream().use { o ->
                            while (true) { val n = z.read(buf); if (n < 0) break; o.write(buf, 0, n) }
                        }
                    }
                    e = z.nextEntry
                }
            }
            "rar" -> Archive(f).use { a ->
                for (h in a.fileHeaders) {
                    val t = targets[h.fileName]
                    if (t != null && !h.isDirectory) t.outputStream().use { o -> a.extractFile(h, o) }
                }
            }
        }
    }

    /**
     * Membaca ISI arsip (.zip, .7z, .rar) untuk mengetahui peruntukannya:
     *  - berisi ROM konsol (.gba / .sfc .smc .fig .swc / .md .gen .smd, atau satu file .bin): ROM diekstrak
     *    ke folder konsol yang benar (GBA, SNES, Genesis) lalu arsipnya dihapus;
     *  - .7z/.rar berisi set ROM arcade: isinya dikemas ulang menjadi .zip di folder arcade (MAME butuh zip);
     *  - .7z/.rar berisi file .zip di dalamnya: zip itu dikeluarkan dan diperiksa lagi;
     *  - .zip arcade dibiarkan apa adanya.
     * Mengembalikan daftar file hasil (kosong = tidak ada perubahan).
     */
    fun normalizeArchive(ctx: Context, arc: File): List<File> {
        if (!isArchive(arc.name)) return emptyList()
        if (BiosInstaller.isBundled(ctx, arc.name)) return emptyList()   // BIOS bawaan: jangan dipilah/dihapus
        val key = "${arc.absolutePath}:${arc.length()}:${arc.lastModified()}"
        if (!checkedZips.add(key)) return emptyList()
        val names = entryNames(arc) ?: return emptyList()
        val out = ArrayList<File>()

        // 1) ROM konsol di dalam arsip
        var picked = names.filter { n ->
            val c = Console.fromExtension(extOf(n)); c != null && !c.isArcade && extOf(n) != "bin"
        }
        if (picked.isEmpty() && names.size == 1 && extOf(names[0]) == "bin") picked = names
        if (picked.isEmpty()) {
            // Satu .bin + berkas pelengkap (txt/jpg/nfo, dll.) = ROM Genesis, bukan set arcade
            val bins = names.filter { extOf(it) == "bin" }
            val others = names.filter { extOf(it) != "bin" }
            if (bins.size == 1 && others.all { extOf(it) in JUNK_EXT || it.endsWith("/") }) picked = bins
        }
        if (picked.isNotEmpty()) {
            val jobs = LinkedHashMap<String, Pair<File, File>>()   // nama entri -> (part, tujuan)
            for (n in picked) {
                val console = Console.fromExtension(extOf(n)) ?: continue
                val base = if (picked.size == 1) arc.nameWithoutExtension else flat(n).substringBeforeLast('.')
                val dir = Paths.roms(ctx, console)
                val dest = File(dir, "$base.${extOf(n)}")
                jobs[n] = File(dir, dest.name + ".part") to dest
            }
            try { extractEntries(arc, jobs.mapValues { it.value.first }) } catch (e: Throwable) {
                val msg = "Gagal mengekstrak ${arc.name}: ${e.javaClass.simpleName} ${e.message ?: ""}".trim()
                lastError = msg
                Log.w("RomLibrary", msg, e)
            }
            for ((part, dest) in jobs.values) {
                if (part.isFile && part.length() > 0 && (dest.delete() || !dest.exists()) && part.renameTo(dest)) out += dest
                else part.delete()
            }
            if (out.size == picked.size) arc.delete()
            return out
        }

        // Zip tanpa ROM konsol dan tanpa zip di dalamnya = arcade, biarkan
        if (extOf(arc.name) == "zip" && names.none { extOf(it) == "zip" }) return emptyList()

        val arcadeDir = Paths.roms(ctx, Console.ARCADE_MAME)

        // 2) .7z/.rar yang membungkus file .zip
        val inner = names.filter { extOf(it) == "zip" }
        if (inner.isNotEmpty()) {
            val jobs = LinkedHashMap<String, Pair<File, File>>()
            for (n in inner) {
                var d = File(arcadeDir, flat(n))
                if (d.absolutePath == arc.absolutePath) d = File(arcadeDir, d.nameWithoutExtension + "_inner.zip")
                jobs[n] = File(arcadeDir, d.name + ".part") to d
            }
            try { extractEntries(arc, jobs.mapValues { it.value.first }) } catch (e: Throwable) { }
            var ok = 0
            for ((part, dest) in jobs.values) {
                if (part.isFile && part.length() > 0 && (dest.delete() || !dest.exists()) && part.renameTo(dest)) {
                    ok++
                    out += normalizeArchive(ctx, dest).ifEmpty { listOf(dest) }
                } else part.delete()
            }
            if (ok == inner.size) arc.delete()
            return out
        }

        // 3) Set ROM arcade dalam .7z/.rar: kemas ulang jadi zip
        val tmp = File(ctx.cacheDir, "unpack_${System.nanoTime()}").apply { mkdirs() }
        val dest = File(arcadeDir, arc.nameWithoutExtension + ".zip")
        val part = File(arcadeDir, dest.name + ".part")
        try {
            val targets = LinkedHashMap<String, File>()
            names.forEach { targets[it] = File(tmp, flat(it)) }
            extractEntries(arc, targets)
            val files = targets.values.distinct().filter { it.isFile }
            if (files.isNotEmpty()) {
                ZipOutputStream(part.outputStream().buffered()).use { zo ->
                    files.forEach { f -> zo.putNextEntry(ZipEntry(f.name)); f.inputStream().use { it.copyTo(zo) }; zo.closeEntry() }
                }
                if ((dest.delete() || !dest.exists()) && part.renameTo(dest)) { out += dest; arc.delete() } else part.delete()
            }
        } catch (e: Throwable) {
            part.delete()
        } finally {
            tmp.deleteRecursively()
        }
        return out
    }

    /** Memeriksa arsip di folder arcade (zip lama, serta .7z/.rar hasil impor/unduhan). Panggil di thread latar. Mengembalikan jumlah arsip yang diproses. */
    fun fixZips(ctx: Context): Int {
        var moved = 0
        Paths.roms(ctx, Console.ARCADE_MAME).listFiles().orEmpty()
            .filter { it.isFile && isArchive(it.name) }
            .forEach { if (normalizeArchive(ctx, it).isNotEmpty()) moved++ }
        return moved
    }

    fun list(ctx: Context): List<Game> {
        migrateOldArcade(ctx)
        return Console.values().filter { it.extensions.isNotEmpty() }.flatMap { c ->
            Paths.roms(ctx, c).listFiles().orEmpty().filter { it.isFile && !it.name.endsWith(".part") && it.extension.lowercase() in c.extensions &&
                !(c == Console.ARCADE_MAME && BiosInstaller.isBundled(ctx, it.name)) }.map { Game(it, c) }
        }.sortedBy { it.title.lowercase() }
    }

    /** Hasil impor folder. */
    data class ImportResult(val imported: Int, val skipped: Int, val failed: Int, val ignored: Int)

    private const val MAX_DEPTH = 8

    /**
     * Mengimpor semua ROM dalam sebuah folder pilihan pengguna (termasuk subfolder) ke folder app.
     * Bekerja lewat Storage Access Framework, sama di Android 5 sampai terbaru. File dengan ekstensi yang tidak dikenal
     * diabaikan; file yang sudah ada dengan ukuran sama dilewati (impor ulang cepat). [onProgress] dipanggil tiap file
     * selesai diproses (jumlah file ROM yang sudah diproses).
     */
    fun importFolder(ctx: Context, tree: Uri, onProgress: (Int) -> Unit = {}): ImportResult {
        var imported = 0; var skipped = 0; var failed = 0; var ignored = 0; var done = 0
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE
        )

        val existing = list(ctx).map { it.title.lowercase() }.toMutableSet()

        fun copyOne(docId: String, name: String, size: Long, console: Console) {
            val dest = File(Paths.roms(ctx, console), File(name).name)
            val srcUri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
            if (size > 0 && dest.isFile && dest.length() == size) { SourceLinks.link(ctx, dest, srcUri); skipped++; return }
            // Zip yang isinya sudah diekstrak ke folder konsol lain: lewati
            if (isArchive(name) && !dest.exists() && File(name).nameWithoutExtension.lowercase() in existing) { skipped++; return }
            val part = File(dest.parentFile, dest.name + ".part")
            try {
                val ok = ctx.contentResolver.openInputStream(srcUri)?.use { input ->
                    part.outputStream().use { out -> input.copyTo(out) }
                } != null
                if (ok && (dest.delete() || !dest.exists()) && part.renameTo(dest)) {
                    imported++
                    existing += dest.nameWithoutExtension.lowercase()
                    // Baca isi zip: ROM GBA/SNES/Genesis dipindah ke konsol yang tepat
                    if (isArchive(dest.name)) {
                        val extracted = normalizeArchive(ctx, dest)
                        extracted.forEach { existing += it.nameWithoutExtension.lowercase() }
                        // Tautkan ke berkas asli hanya bila arsip menghasilkan tepat satu game (atau tetap utuh sebagai zip arcade)
                        if (extracted.size == 1) SourceLinks.link(ctx, extracted[0], srcUri)
                        else if (extracted.isEmpty() && dest.exists()) SourceLinks.link(ctx, dest, srcUri)
                    } else SourceLinks.link(ctx, dest, srcUri)
                } else { part.delete(); failed++ }
            } catch (e: Exception) {
                part.delete(); failed++
            }
        }

        fun walk(docId: String, depth: Int) {
            val files = ArrayList<Triple<String, String, Long>>()
            val dirs = ArrayList<String>()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            try {
                ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2)
                        val size = if (c.isNull(3)) -1L else c.getLong(3)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) dirs += id else files += Triple(id, name, size)
                    }
                }
            } catch (e: Exception) {
                return
            }
            for ((id, name, size) in files) {
                val console = Console.fromExtension(name.substringAfterLast('.', "").lowercase())
                if (console == null) { ignored++; continue }
                copyOne(id, name, size, console)
                done++; onProgress(done)
            }
            if (depth < MAX_DEPTH) dirs.forEach { walk(it, depth + 1) }
        }

        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return ImportResult(imported, skipped, failed, ignored)
    }

    /** Hapus file game di library DAN berkas aslinya di file manager (bila hasil impor dan izin tulis masih ada). */
    fun delete(ctx: Context, game: Game): Boolean {
        val ok = game.file.delete() || !game.file.exists()
        SourceLinks.deleteSource(ctx, game.file)
        SourceLinks.rescan(ctx, game.file)
        return ok
    }

    /** Hapus file game sekaligus save (SRAM), save state, dan cheat miliknya. */
    fun deleteWithData(ctx: Context, game: Game): Boolean {
        val re = Regex("^" + Regex.escape(game.title) + "(\\.(fbneo|fba2012|mame2000|mame2003p?|mame2010))?\\.(sram\\.bin|[^.]+\\.state)$")
        val gone = ArrayList<File>()
        listOf(Paths.saves(ctx), Paths.states(ctx)).forEach { d ->
            d.listFiles().orEmpty().filter { it.isFile && re.matches(it.name) }.forEach { if (it.delete()) gone += it }
        }
        File(Paths.cheats(ctx), "${game.title}.json").let { if (it.delete()) gone += it }
        SourceLinks.rescan(ctx, *gone.toTypedArray())
        return delete(ctx, game)
    }
}

package com.allinone.emulator.ui

import android.content.Context
import android.os.Build
import com.seedlessds.app.filesystem.PathCache
import java.io.File

/**
 * Pendukung core NDS SeedlessDS (SeedlessCoreDS, GPL-3.0-or-later) yang ditanam di APK ini.
 * Core hanya ada untuk arm64-v8a; di APK/perangkat lain NDS tetap memakai DeSmuME/melonDS.
 */
object SeedlessSupport {
    private const val ASSET_ROOT = "seedlessds"

    /** Core terpasang di APK ini dan HP-nya arm64 (library asli sudah bisa dimuat). */
    val available: Boolean by lazy {
        Build.SUPPORTED_ABIS.any { it == "arm64-v8a" } &&
            try { !com.seedlessds.core.SeedlessCore.startupError } catch (_: Throwable) { false }
    }

    /** Salin BIOS pengganti, database game, dan shader ke filesDir/SeedlessDS (dilewati bila sudah ada dan ukurannya sama). */
    fun ensureInstalled(ctx: Context) {
        val sys = File(ctx.filesDir, PathCache.DATA_DIR).apply { mkdirs() }
        copyAsset(ctx, "game_database.xml", File(sys, "game_database.xml"))
        copyAsset(ctx, "LC_default.dat", File(sys, "config/LC_default.dat"))
        copyAsset(ctx, "nds_bios_arm7_replacement.bin", File(sys, "system/nds_bios_arm7_replacement.bin"))
        copyAsset(ctx, "nds_bios_arm9_replacement.bin", File(sys, "system/nds_bios_arm9_replacement.bin"))
        copyDir(ctx, "shaders", File(sys, "shaders"))
        listOf("savestates", "backup", "cheats", "user").forEach { File(sys, it).mkdirs() }
    }

    private fun copyAsset(ctx: Context, name: String, out: File) {
        val path = "$ASSET_ROOT/$name"
        val size = try { ctx.assets.openFd(path).length } catch (_: Exception) { -1L }
        if (out.exists() && (size < 0 || out.length() == size)) return
        out.parentFile?.mkdirs()
        ctx.assets.open(path).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
    }

    private fun copyDir(ctx: Context, rel: String, dest: File) {
        val path = "$ASSET_ROOT/$rel"
        val entries = try { ctx.assets.list(path) } catch (_: Exception) { null } ?: return
        if (entries.isEmpty()) {
            dest.parentFile?.mkdirs()
            if (!dest.exists()) ctx.assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            return
        }
        dest.mkdirs()
        for (e in entries) copyDir(ctx, "$rel/$e", File(dest, e))
    }

    /**
     * Bit konfigurasi core (sama dengan DsSettings.pack() di SeedlessDS). Bawaan di sini memilih jalur paling ringan:
     * resolusi asli 256x192 (tanpa hires 3D), tanpa Lua, tanpa filter shader.
     */
    fun configBits(): Long {
        val cpus = Runtime.getRuntime().availableProcessors()
        val threads = if (cpus >= 6) 8 else if (cpus >= 5) 4 else if (cpus >= 4) 3 else if (cpus >= 2) 2 else 1
        var v = 0L
        v = v or (4L and 15L)                  // frameskipValue = 4
        v = v or (1L shl 5)                    // frameskipType 0 (otomatis)
        v = v or ((3L and 3L) shl 8)           // audioLatency = 3
        v = v or ((2L and 15L) shl 12)         // ffwdSpeed = 2
        v = v or ((threads.toLong() and 15L) shl 16)
        v = v or ((2L and 7L) shl 32)          // autofireSpeed
        v = v or ((1L and 3L) shl 37)          // micLevel
        v = v or ((1L and 15L) shl 43)         // slot2Type
        v = v or 0x80000000L                   // suara
        v = v or 0x8000000L                    // cheat aktif
        v = v or 0x4000000L                    // mikrofon
        v = v or 0x2000000L                    // backup ikut di save state
        return v
    }
}

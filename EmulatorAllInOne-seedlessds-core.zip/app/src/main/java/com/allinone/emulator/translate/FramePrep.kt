package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import androidx.annotation.RequiresApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Menangkap isi layar game (GLSurfaceView) tanpa menyertakan tombol/overlay. Butuh Android 7.0+. */
object FrameCapture {
    fun supported() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    suspend fun grab(view: SurfaceView): Bitmap? {
        if (!supported() || view.width <= 0 || view.height <= 0) return null
        return grabN(view)
    }

    /**
     * Tangkap layar setelah teks selesai muncul. Banyak game menampilkan dialog huruf demi huruf; membaca di tengah
     * animasi menghasilkan teks terpotong. Dua tangkapan berurutan (jeda 120 ms) dibandingkan pada 40% bagian bawah
     * layar; bila sama, teks sudah stabil. Maksimal 8 percobaan (latar yang terus bergerak tidak akan pernah sama).
     */
    suspend fun grabStable(view: SurfaceView): Bitmap? {
        var prev = grab(view) ?: return null
        repeat(8) {
            delay(120)
            val cur = grab(view) ?: return prev
            if (sameBottom(prev, cur)) { prev.recycle(); return cur }
            prev.recycle()
            prev = cur
        }
        return prev
    }

    /**
     * Bagian piksel (0..1) yang berubah di antara dua tangkapan, mulai dari fromFrac tinggi layar (0 = seluruh layar,
     * 0,6 = 40% bagian bawah); 1 bila ukuran beda. Dipakai live translate.
     */
    fun frameDiff(a: Bitmap, b: Bitmap, fromFrac: Float = 0f): Float {
        if (a.width != b.width || a.height != b.height) return 1f
        val w = a.width
        val y0 = (a.height * fromFrac).toInt()
        val rows = a.height - y0
        if (rows <= 0) return 0f
        val pa = IntArray(w * rows)
        val pb = IntArray(w * rows)
        a.getPixels(pa, 0, w, 0, y0, w, rows)
        b.getPixels(pb, 0, w, 0, y0, w, rows)
        var diff = 0
        var n = 0
        var y = 0
        while (y < rows) {
            var x = 0
            while (x < w) {
                val i = y * w + x
                if (pa[i] != pb[i]) {
                    val d = kotlin.math.abs(((pa[i] shr 16) and 0xFF) - ((pb[i] shr 16) and 0xFF)) +
                        kotlin.math.abs(((pa[i] shr 8) and 0xFF) - ((pb[i] shr 8) and 0xFF)) +
                        kotlin.math.abs((pa[i] and 0xFF) - (pb[i] and 0xFF))
                    if (d > 24) diff++
                }
                n++
                x += 2
            }
            y += 2
        }
        return if (n == 0) 0f else diff.toFloat() / n
    }

    private fun sameBottom(a: Bitmap, b: Bitmap): Boolean {
        if (a.width != b.width || a.height != b.height) return false
        val w = a.width
        val y0 = (a.height * 0.6f).toInt()
        val rows = a.height - y0
        val pa = IntArray(w * rows)
        val pb = IntArray(w * rows)
        a.getPixels(pa, 0, w, 0, y0, w, rows)
        b.getPixels(pb, 0, w, 0, y0, w, rows)
        var diff = 0
        var n = 0
        var y = 0
        while (y < rows) {
            var x = 0
            while (x < w) {
                val i = y * w + x
                if (pa[i] != pb[i]) {
                    val d = kotlin.math.abs(((pa[i] shr 16) and 0xFF) - ((pb[i] shr 16) and 0xFF)) +
                        kotlin.math.abs(((pa[i] shr 8) and 0xFF) - ((pb[i] shr 8) and 0xFF)) +
                        kotlin.math.abs((pa[i] and 0xFF) - (pb[i] and 0xFF))
                    if (d > 24) diff++
                }
                n++
                x += 2
            }
            y += 2
        }
        return diff <= max(2, n / 5000)      // < 0,02% piksel yang berubah
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private suspend fun grabN(view: SurfaceView): Bitmap? = suspendCancellableCoroutine { cont ->
        val bmp = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        try {
            PixelCopy.request(
                view, bmp,
                PixelCopy.OnPixelCopyFinishedListener { r ->
                    if (cont.isActive) cont.resume(if (r == PixelCopy.SUCCESS) bmp else null)
                },
                Handler(Looper.getMainLooper())
            )
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(null)
        }
    }
}

/**
 * Pra-pemrosesan supaya teks piksel/buram lebih mudah dibaca OCR:
 * ukuran dinormalkan, kontras diregangkan, ditajamkan, dibalik, dibinerkan (Otsu), serta pemisahan teks terang/gelap lewat warna (untuk teks putih di kotak biru muda).
 */
object FramePrep {
    private const val MAX_SIDE = 1600
    private const val MIN_SIDE = 1100
    const val VARIANT_COUNT = 15

    /** Urutan percobaan varian OCR: varian untuk huruf ber-outline (11, 2, 3, 12) diletakkan di depan karena murah dan sering menentukan. */
    val ORDER = intArrayOf(0, 1, 11, 2, 13, 3, 12, 4, 14, 5, 6, 7, 8, 9, 10)
    private const val INK_LIGHT = 0
    private const val INK_DARK = 1
    private const val INK_COOL = 2
    private const val INK_OUTLINE = 3
    private const val INK_OUTLINE_FILL = 4   // garis tepi abu-biru + bagian dalam goresan yang tipis diisi (huruf perak ber-outline)
    private const val INK_OUTLINE_THIN = 5   // hanya garis tepi tipis (tanpa bayangan jatuh) untuk huruf ber-outline tebal

    /** Kemiringan (shear) yang dikoreksi pada varian huruf miring; 0 = bukan varian miring. */
    fun shearOf(variant: Int): Float = when (variant) { 6 -> 0.25f; 7 -> 0.45f; else -> 0f }

    fun crop(src: Bitmap, bottomOnly: Boolean): Bitmap {
        if (!bottomOnly) return src
        val h = (src.height * 0.45f).toInt().coerceAtLeast(1)
        return Bitmap.createBitmap(src, 0, src.height - h, src.width, h)
    }

    fun normalizeSize(src: Bitmap): Bitmap {
        val longSide = max(src.width, src.height)
        val scale = when {
            longSide > MAX_SIDE -> MAX_SIDE.toFloat() / longSide
            longSide < MIN_SIDE -> MIN_SIDE.toFloat() / longSide
            else -> 1f
        }
        if (scale == 1f) return src
        return Bitmap.createScaledBitmap(
            src,
            (src.width * scale).roundToInt().coerceAtLeast(1),
            (src.height * scale).roundToInt().coerceAtLeast(1),
            true
        )
    }

    /** Varian dibuat malas (hanya saat dibutuhkan) agar hemat RAM dan waktu. */
    class Variants(private val base: Bitmap) {
        private val w = base.width
        private val h = base.height
        private val cache = arrayOfNulls<Bitmap>(VARIANT_COUNT)
        private var stretched: IntArray? = null
        private var sharpened: IntArray? = null

        fun get(i: Int): Bitmap {
            cache[i]?.let { return it }
            val b = build(i)
            cache[i] = b
            return b
        }

        fun release() {
            for (b in cache) if (b != null && b !== base && !b.isRecycled) b.recycle()
        }

        private fun gray(): IntArray = stretched ?: stretch(grayOf(base)).also { stretched = it }
        private fun sharp(): IntArray = sharpened ?: sharpen(gray(), w, h).also { sharpened = it }

        private fun build(i: Int): Bitmap = when (i) {
            0 -> base                                       // warna asli
            1 -> inkMask(INK_LIGHT)                         // teks terang (putih) dipisah lewat warna -> hitam di atas putih
            2 -> inkMask(INK_OUTLINE)                       // garis tepi/bayangan abu-biru huruf -> huruf ber-outline hitam di atas putih
            3 -> inkMask(INK_COOL)                          // teks putih kebiruan di atas gambar hangat/krem (cutscene)
            4 -> toBitmap(gray(), w, h, false)              // abu-abu, kontras diregangkan
            5 -> toBitmap(sharp(), w, h, false)             // + dipertajam
            6 -> shearBitmap(sharp(), w, h, shearOf(6))      // huruf miring ringan diluruskan
            7 -> shearBitmap(sharp(), w, h, shearOf(7))      // huruf miring kuat diluruskan
            8 -> toBitmap(sharp(), w, h, true)              // dibalik
            9 -> toBitmap(otsu(sharp()), w, h, false)       // hitam-putih (Otsu)
            13 -> softInk()                                 // teks terang dipisah lalu dihaluskan: tepi bergerigi font piksel jadi lembut
            14 -> toBitmap(blurGray(gray(), max(1, w / 700)), w, h, false)   // abu-abu + dihaluskan
            11 -> inkMask(INK_OUTLINE_FILL)                 // huruf perak ber-outline (judul cutscene): outline + isi goresan
            12 -> inkMask(INK_OUTLINE_THIN)                 // outline saja, tanpa dilasi
            else -> inkMask(INK_DARK)                       // teks gelap dipisah lewat warna -> hitam di atas putih
        }

        /**
         * Pisahkan teks dari latar lewat WARNA, bukan lewat keabuan: teks putih di kotak biru muda (GBA) hampir
         * sama terangnya dengan latar sehingga varian abu-abu/Otsu gagal. Teks terang = piksel yang SEMUA kanal
         * warnanya tinggi (min R,G,B); teks gelap = piksel yang semua kanalnya rendah (max R,G,B). Ambang
         * mengikuti median gambar. Hasilnya ditebalkan 1 piksel (goresan huruf piksel sangat tipis), lalu
         * digambar hitam di atas putih supaya mudah dibaca OCR.
         */
        private fun inkMask(kind: Int): Bitmap {
            val light = kind != INK_DARK
            val px = IntArray(w * h)
            base.getPixels(px, 0, w, 0, 0, w, h)
            val ch = IntArray(w * h)
            val hist = IntArray(256)
            for (k in px.indices) {
                val c = px[k]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val v = if (light) min(r, min(g, b)) else max(r, max(g, b))
                // INK_COOL: hanya piksel terang yang biru-nya tidak kalah dari merah (teks putih/lilac); krem/sepia (R > B) ditolak
                ch[k] = when (kind) {
                    INK_COOL -> if (b < 200 || b < r - 6) 0 else b
                    // Outline/bayangan huruf font game berwarna abu-biru (B > R, tidak terlalu gelap/terang). Warna ini
                    // jarang ada pada gambar latar (sepia/krem/hitam) sehingga bentuk huruf tetap utuh meski isinya
                    // sewarna latar.
                    INK_OUTLINE -> if (b - r >= 8 && min(r, min(g, b)) >= 100 && max(r, max(g, b)) <= 205) 255 else 0
                    // Huruf perak/krom: isi terang bergradasi (~190-240) dikelilingi outline abu-biru yang lebih gelap (~110-175).
                    INK_OUTLINE_FILL, INK_OUTLINE_THIN ->
                        if (b - r >= 8 && min(r, min(g, b)) >= 90 && max(r, max(g, b)) <= 175) 255 else 0
                    else -> v
                }
                hist[ch[k]]++
            }
            var acc = 0
            var med = 127
            for (v in 0..255) { acc += hist[v]; if (acc >= ch.size / 2) { med = v; break } }
            val thr = if (kind == INK_OUTLINE || kind == INK_OUTLINE_FILL || kind == INK_OUTLINE_THIN) 128
                      else if (kind == INK_COOL) 205
                      else if (light) (med + (255 - med) * 0.4f).toInt().coerceIn(165, 225)
                      else (med * 0.45f).toInt().coerceIn(40, 110)
            val ink = BooleanArray(w * h) { if (light) ch[it] >= thr else ch[it] <= thr }
            if (kind == INK_OUTLINE_THIN) return maskBitmap(ink)
            // Tebalkan 1 piksel (dilasi 3x3 terpisah: horizontal lalu vertikal)
            val hor = BooleanArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    hor[row + x] = ink[row + x] || (x > 0 && ink[row + x - 1]) || (x < w - 1 && ink[row + x + 1])
                }
            }
            val on = BooleanArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    on[row + x] = hor[row + x] || (y > 0 && hor[row - w + x]) || (y < h - 1 && hor[row + w + x])
                }
            }
            // INK_COOL (cutscene: teks putih di atas gambar terang) dibiarkan utuh: bagian teks yang menempel pada
            // area putih tidak bisa dipisahkan lewat warna, tetapi huruf di bagian lain tetap bersih dan terbaca.
            if (kind == INK_OUTLINE_FILL) fillThinHoles(on, max(3, (w * 0.0045f).toInt()))
            val glyphH = if (kind == INK_COOL || kind == INK_OUTLINE || kind == INK_OUTLINE_FILL) 0 else dropBigBlobs(on)
            if (glyphH > 0) {
                peelAreas(on, (glyphH * 0.35f).toInt().coerceIn(4, 40))
                dropBigBlobs(on)
            }
            val out = IntArray(w * h)
            for (k in out.indices) out[k] = if (on[k]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        }


        /**
         * Font piksel (kotak-kotak) sulit dibaca pengenal Jepang yang dilatih dengan huruf mulus. Topeng teks terang
         * dihaluskan dengan blur kotak kecil supaya goresan bergerigi menjadi tepi lembut seperti huruf biasa.
         */
        private fun softInk(): Bitmap {
            val m = inkMask(INK_LIGHT)
            val g = IntArray(w * h)
            m.getPixels(g, 0, w, 0, 0, w, h)
            for (k in g.indices) g[k] = g[k] and 0xFF
            if (m !== base && !m.isRecycled) m.recycle()
            return toBitmap(blurGray(g, max(1, w / 500)), w, h, false)
        }

        /** Blur kotak terpisah (horizontal lalu vertikal) dengan jumlah berjalan, O(n). */
        private fun blurGray(g: IntArray, r: Int): IntArray {
            val k = 2 * r + 1
            val tmp = IntArray(w * h)
            val out = IntArray(w * h)
            for (y in 0 until h) {
                val row = y * w
                var sum = 0
                for (x in -r..r) sum += g[row + x.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[row + x] = sum / k
                    sum += g[row + (x + r + 1).coerceAtMost(w - 1)] - g[row + (x - r).coerceAtLeast(0)]
                }
            }
            for (x in 0 until w) {
                var sum = 0
                for (y in -r..r) sum += tmp[y.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    out[y * w + x] = sum / k
                    sum += tmp[(y + r + 1).coerceAtMost(h - 1) * w + x] - tmp[(y - r).coerceAtLeast(0) * w + x]
                }
            }
            return out
        }

        private fun maskBitmap(on: BooleanArray): Bitmap {
            val out = IntArray(w * h)
            for (k in out.indices) out[k] = if (on[k]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        }

        /**
         * Isi lubang kecil yang tertutup rapat oleh topeng (bagian dalam goresan huruf ber-outline) supaya huruf menjadi
         * hitam padat. Lubang yang tipis (tebal <= 2r) diisi; lubang besar (rongga huruf seperti pada ゆ, ま, 晶) dibiarkan.
         * Lubang yang tersambung ke tepi gambar tidak pernah diisi.
         */
        private fun fillThinHoles(on: BooleanArray, r: Int) {
            val n = w * h
            val comp = IntArray(n)            // 0 = belum, id komponen latar (piksel !on)
            val stack = IntArray(n)
            var id = 0
            val compSize = ArrayList<Int>()
            val touchesEdge = ArrayList<Boolean>()
            compSize += 0; touchesEdge += true
            for (s0 in 0 until n) {
                if (on[s0] || comp[s0] != 0) continue
                id++
                var sp = 0
                var size = 0
                var edge = false
                stack[sp++] = s0; comp[s0] = id
                while (sp > 0) {
                    val q = stack[--sp]
                    size++
                    val x = q % w
                    val y = q / w
                    if (x == 0 || y == 0 || x == w - 1 || y == h - 1) edge = true
                    if (x > 0 && !on[q - 1] && comp[q - 1] == 0) { comp[q - 1] = id; stack[sp++] = q - 1 }
                    if (x < w - 1 && !on[q + 1] && comp[q + 1] == 0) { comp[q + 1] = id; stack[sp++] = q + 1 }
                    if (y > 0 && !on[q - w] && comp[q - w] == 0) { comp[q - w] = id; stack[sp++] = q - w }
                    if (y < h - 1 && !on[q + w] && comp[q + w] == 0) { comp[q + w] = id; stack[sp++] = q + w }
                }
                compSize += size; touchesEdge += edge
            }
            if (id == 0) return
            // Ketebalan lubang = jarak terjauh ke piksel "on" (transformasi jarak pendek 2 sapuan, jarak kotak-kota).
            val d = IntArray(n) { if (on[it]) 0 else Int.MAX_VALUE / 2 }
            for (y in 0 until h) for (x in 0 until w) {
                val q = y * w + x
                if (on[q]) continue
                var v = d[q]
                if (x > 0) v = min(v, d[q - 1] + 1)
                if (y > 0) v = min(v, d[q - w] + 1)
                d[q] = v
            }
            for (y in h - 1 downTo 0) for (x in w - 1 downTo 0) {
                val q = y * w + x
                if (on[q]) continue
                var v = d[q]
                if (x < w - 1) v = min(v, d[q + 1] + 1)
                if (y < h - 1) v = min(v, d[q + w] + 1)
                d[q] = v
            }
            val maxD = IntArray(id + 1)
            for (q in 0 until n) { val c = comp[q]; if (c > 0 && d[q] > maxD[c]) maxD[c] = d[q] }
            for (q in 0 until n) {
                val c = comp[q]
                if (c > 0 && !touchesEdge[c] && maxD[c] <= r) on[q] = true
            }
        }

        /**
         * Buang gumpalan yang jauh lebih besar dari huruf (wajah tokoh, bingkai kotak dialog, gambar latar terang)
         * supaya OCR hanya melihat huruf. Ukuran huruf = median tinggi gumpalan; gumpalan yang tingginya > 2,5x
         * atau lebarnya > 8x tinggi huruf dibuang. Dilewati bila gumpalannya terlalu sedikit untuk dibandingkan.
         */
        private fun dropBigBlobs(on: BooleanArray): Int {
            var total = 0
            for (b in on) if (b) total++
            if (total == 0) return 0
            val order = IntArray(total)
            val seen = BooleanArray(on.size)
            val starts = ArrayList<Int>()
            val sizes = ArrayList<Int>()
            val hs = ArrayList<Int>()
            val ws = ArrayList<Int>()
            var pos = 0
            for (s0 in on.indices) {
                if (!on[s0] || seen[s0]) continue
                val begin = pos
                order[pos++] = s0
                seen[s0] = true
                var head = begin
                var minX = w; var maxX = 0; var minY = h; var maxY = 0
                while (head < pos) {
                    val q0 = order[head++]
                    val x = q0 % w
                    val y = q0 / w
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    for (dy in -1..1) {
                        val ny = y + dy
                        if (ny < 0 || ny >= h) continue
                        for (dx in -1..1) {
                            val nx = x + dx
                            if (nx < 0 || nx >= w || (dx == 0 && dy == 0)) continue
                            val q = ny * w + nx
                            if (on[q] && !seen[q]) { seen[q] = true; order[pos++] = q }
                        }
                    }
                }
                starts += begin
                sizes += (pos - begin)
                hs += (maxY - minY + 1)
                ws += (maxX - minX + 1)
            }
            val sample = ArrayList<Int>()
            for (c in starts.indices) if (sizes[c] >= 40) sample += hs[c]
            if (sample.size < 5) return 0
            sample.sort()
            val medH = sample[sample.size / 2]
            for (c in starts.indices) {
                if (hs[c] > medH * 2.5f || ws[c] > medH * 8f) {
                    for (i in starts[c] until starts[c] + sizes[c]) on[order[i]] = false
                }
            }
            return medH
        }

        /**
         * Buang AREA lebar yang menempel pada huruf (wajah putih/gambar terang di belakang teks): area yang tahan
         * erosi sebesar r (goresan huruf lebih tipis dari 2r+1 sehingga hilang) ditandai sebagai "inti area",
         * dikembalikan dengan dilasi r+2, lalu dihapus dari topeng. Memakai gambar integral supaya O(n).
         */
        private fun peelAreas(on: BooleanArray, r: Int) {
            val k = 2 * r + 1
            val iw = w + 1
            fun integral(src: BooleanArray): IntArray {
                val ii = IntArray(iw * (h + 1))
                for (y in 0 until h) {
                    var rowSum = 0
                    for (x in 0 until w) {
                        if (src[y * w + x]) rowSum++
                        ii[(y + 1) * iw + (x + 1)] = ii[y * iw + (x + 1)] + rowSum
                    }
                }
                return ii
            }
            fun box(ii: IntArray, x0: Int, y0: Int, x1: Int, y1: Int): Int =   // [x0,x1) x [y0,y1)
                ii[y1 * iw + x1] - ii[y0 * iw + x1] - ii[y1 * iw + x0] + ii[y0 * iw + x0]
            val ii = integral(on)
            val core = BooleanArray(w * h)
            var any = false
            for (y in r until h - r) {
                for (x in r until w - r) {
                    if (on[y * w + x] && box(ii, x - r, y - r, x + r + 1, y + r + 1) == k * k) { core[y * w + x] = true; any = true }
                }
            }
            if (!any) return
            val ic = integral(core)
            val d = r + 2
            for (y in 0 until h) {
                val y0 = maxOf(0, y - d); val y1 = minOf(h, y + d + 1)
                for (x in 0 until w) {
                    if (!on[y * w + x]) continue
                    val x0 = maxOf(0, x - d); val x1 = minOf(w, x + d + 1)
                    if (box(ic, x0, y0, x1, y1) > 0) on[y * w + x] = false
                }
            }
        }

        private fun grayOf(b: Bitmap): IntArray {
            val p = IntArray(w * h)
            b.getPixels(p, 0, w, 0, 0, w, h)
            for (k in p.indices) {
                val c = p[k]
                p[k] = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            }
            return p
        }
    }

    private fun stretch(g: IntArray): IntArray {
        val hist = IntArray(256)
        for (v in g) hist[v]++
        val total = g.size
        var acc = 0
        var lo = 0
        var hi = 255
        for (v in 0..255) { acc += hist[v]; if (acc >= total * 0.02) { lo = v; break } }
        acc = 0
        for (v in 255 downTo 0) { acc += hist[v]; if (acc >= total * 0.02) { hi = v; break } }
        if (hi - lo < 16) { lo = 0; hi = 255 }
        val span = (hi - lo).toFloat()
        val out = IntArray(g.size)
        for (k in g.indices) out[k] = (((g[k] - lo) * 255f) / span).toInt().coerceIn(0, 255)
        return out
    }

    private fun sharpen(g: IntArray, w: Int, h: Int): IntArray {
        val out = g.copyOf()
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val v = 5 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]
                out[i] = v.coerceIn(0, 255)
            }
        }
        return out
    }

    private fun otsu(g: IntArray): IntArray {
        val hist = IntArray(256)
        for (v in g) hist[v]++
        val total = g.size.toDouble()
        var sum = 0.0
        for (t in 0..255) sum += t * hist[t].toDouble()
        var sumB = 0.0
        var wB = 0.0
        var best = 0.0
        var thr = 127
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0.0) continue
            val wF = total - wB
            if (wF == 0.0) break
            sumB += t * hist[t].toDouble()
            val mB = sumB / wB
            val mF = (sum - sumB) / wF
            val between = wB * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; thr = t }
        }
        val out = IntArray(g.size)
        for (k in g.indices) out[k] = if (g[k] > thr) 255 else 0
        return out
    }

    /**
     * Meluruskan huruf miring ke kanan: baris atas digeser ke kiri sebanding jaraknya dari tengah.
     * Lebar bertambah supaya tidak ada yang terpotong; tepi diisi dengan piksel tepi (tanpa garis aneh).
     * Peta balik koordinat: x asli = x' - (s*h/2 + s*(y - h/2)).
     */
    private fun shearBitmap(g: IntArray, w: Int, h: Int, s: Float): Bitmap {
        val extra = kotlin.math.ceil(s * h).toInt()
        val nw = w + extra
        val mid = h / 2f
        val off = s * h / 2f
        val out = IntArray(nw * h)
        for (y in 0 until h) {
            val shift = (s * (y - mid) + off).roundToInt()
            val row = y * w
            val orow = y * nw
            for (x in 0 until nw) {
                val sx = (x - shift).coerceIn(0, w - 1)
                out[orow + x] = g[row + sx]
            }
        }
        return toBitmap(out, nw, h, false)
    }

    private fun toBitmap(g: IntArray, w: Int, h: Int, invert: Boolean): Bitmap {
        val px = IntArray(g.size)
        for (k in g.indices) {
            val v = if (invert) 255 - g[k] else g[k]
            px[k] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}


/**
 * Mengembalikan gambar layar ke piksel asli game. Layar HP memperbesar game (mis. GBA 240x160 jadi 1620x1080) dengan
 * filter yang melembutkan tepi huruf; OCR lebih mudah membaca huruf piksel yang tepinya tegas. Tiap piksel layar diganti
 * warna titik tengah blok piksel game-nya. Ukuran dan koordinat gambar TIDAK berubah.
 * Letak game di dalam layar dicari otomatis (seluruh layar, atau persegi 4:3 / 3:2 di tengah) dan hanya dipakai bila
 * garis blok benar-benar cocok dengan perubahan warna di gambar; bila tidak cocok mengembalikan null (gambar asli dipakai).
 */
object PixelSnap {
    private fun d(a: Int, b: Int): Int =
        kotlin.math.abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)) +
            kotlin.math.abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)) +
            kotlin.math.abs((a and 0xFF) - (b and 0xFF))

    /** Rasio (selaras / bergeser setengah blok): makin kecil makin cocok. */
    private fun ratio(px: IntArray, w: Int, h: Int, l: Int, t: Int, rw: Int, rh: Int, nw: Int, nh: Int): Double {
        val sx = rw.toDouble() / nw
        val sy = rh.toDouble() / nh
        var aligned = 0L
        var shifted = 0L
        var y = t
        while (y < t + rh) {
            var x = l
            while (x < l + rw) {
                val fx = (x - l) / sx
                val fy = (y - t) / sy
                val cx = (l + ((fx.toInt() + 0.5) * sx).toInt()).coerceIn(0, w - 1)
                val cy = (t + ((fy.toInt() + 0.5) * sy).toInt()).coerceIn(0, h - 1)
                val hx = (l + (((fx + 0.5).toInt()) * sx).toInt()).coerceIn(0, w - 1)
                val hy = (t + (((fy + 0.5).toInt()) * sy).toInt()).coerceIn(0, h - 1)
                val p = px[y * w + x]
                aligned += d(p, px[cy * w + cx])
                shifted += d(p, px[hy * w + hx])
                x += 3
            }
            y += 3
        }
        return aligned.toDouble() / (shifted + 1)
    }

    fun snap(frame: Bitmap, nw: Int, nh: Int): Bitmap? {
        val w = frame.width
        val h = frame.height
        if (w < nw * 2 || h < nh * 2) return null
        val px = IntArray(w * h)
        frame.getPixels(px, 0, w, 0, 0, w, h)
        val rects = ArrayList<IntArray>()
        rects += intArrayOf(0, 0, w, h)
        for ((a, b) in listOf(4 to 3, 3 to 2)) {
            var rw = w
            var rh = rw * b / a
            if (rh > h) { rh = h; rw = rh * a / b }
            if (rw != w || rh != h) rects += intArrayOf((w - rw) / 2, (h - rh) / 2, rw, rh)
        }
        var best: IntArray? = null
        var bestR = 1.0
        for (r in rects) {
            val q = ratio(px, w, h, r[0], r[1], r[2], r[3], nw, nh)
            if (q < bestR) { bestR = q; best = r }
        }
        val r = best ?: return null
        if (bestR > 0.6) return null
        val sx = r[2].toDouble() / nw
        val sy = r[3].toDouble() / nh
        val out = px.copyOf()
        for (y in r[1] until r[1] + r[3]) {
            val cy = (r[1] + ((((y - r[1]) / sy).toInt() + 0.5) * sy).toInt()).coerceIn(0, h - 1)
            for (x in r[0] until r[0] + r[2]) {
                val cx = (r[0] + ((((x - r[0]) / sx).toInt() + 0.5) * sx).toInt()).coerceIn(0, w - 1)
                out[y * w + x] = px[cy * w + cx]
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}

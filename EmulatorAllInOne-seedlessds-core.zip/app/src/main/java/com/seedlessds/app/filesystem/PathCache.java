package com.seedlessds.app.filesystem;

import android.content.Context;

import androidx.annotation.Keep;

import java.io.File;
import java.io.IOException;

/**
 * Penghubung berkas untuk core SeedlessDS (dipanggil dari native lewat SeedlessPathCache).
 * Versi ringkas dari SeedlessDS 1.0.1: semua data (BIOS pengganti, shader, save, state) di filesDir/SeedlessDS,
 * ROM dibuka lewat path aslinya. Tanpa SaveLocation/URI.
 */
@Keep
public class PathCache {
    public static final String DATA_DIR = "SeedlessDS";
    public static final String SYS_PREFIX = DATA_DIR + File.separator;
    public static final String USER_PREFIX = "User" + File.separator;

    private static Context ctx;
    private static String romKey;
    private static String romRealPath;
    private static String romName;

    public static void setAppContext(Context c) {
        ctx = c.getApplicationContext();
    }

    public static File systemDir() {
        File d = new File(ctx.getFilesDir(), DATA_DIR);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File userDir() {
        File d = new File(systemDir(), "user");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File resolve(String path) {
        if (path.startsWith("/")) return new File(path);
        String p = sanitize(path);
        if (p.startsWith(SYS_PREFIX)) return new File(systemDir(), p.substring(SYS_PREFIX.length()));
        if (p.startsWith(USER_PREFIX)) return new File(userDir(), p.substring(USER_PREFIX.length()));
        throw new RuntimeException("Bad path prefix: " + path);
    }

    public static synchronized void changeRom(String key, String realPath, String name) {
        romKey = key;
        romRealPath = realPath;
        romName = name;
    }

    public static synchronized NativePathHandle open(String path, String mode) {
        if (romKey != null && romKey.equals(path) && romRealPath != null) {
            return new NativePathHandle(romRealPath, romName != null ? romName : new File(romRealPath).getName());
        }
        File f = resolve(path);
        String m = mode.replace("b", "");
        boolean write = m.contains("w") || m.contains("+") || m.contains("a");
        if (write) {
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            if (!f.exists()) {
                try { f.createNewFile(); } catch (IOException ignored) { }
            }
        }
        return new NativePathHandle(f);
    }

    public static synchronized boolean remove(String path) {
        File f = resolve(path);
        return f.exists() && f.delete();
    }

    public static synchronized boolean rename(String from, String to) {
        File a = resolve(from);
        if (!a.exists()) return false;
        File b = resolve(to);
        if (b.exists() && !b.delete()) return false;
        File parent = b.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        return a.renameTo(b);
    }

    private static String sanitize(String s) {
        String sep = File.separator;
        return s.replaceAll(sep + "\\+", sep).replaceAll("^" + sep, "");
    }
}

package com.swordfish.libretrodroid

/** Status sesi netplay rollback (dibaca dari native). */
data class NetplayStatus(
    val state: State,
    val error: Error,
    val pingMs: Int,
    val lastRollbackFrames: Int,
    val desync: Boolean,
    val localPlayer: Int, // 0 = host (pemain 1), 1 = tamu (pemain 2)
    val frame: Int
) {
    enum class State { OFF, HOST_WAITING, CLIENT_CONNECTING, SYNCING, RUNNING, ENDED }
    enum class Error {
        NONE, GAME_MISMATCH, CONNECT, TIMEOUT, VERSION, STATE_TOO_BIG, SOCKET, PEER_LEFT
    }

    companion object {
        fun fromNative(a: IntArray): NetplayStatus = NetplayStatus(
            State.values().getOrElse(a[0]) { State.OFF },
            Error.values().getOrElse(a[1]) { Error.NONE },
            a[2], a[3], a[4] != 0, a[5], a[6]
        )
    }
}
